import SignUp from "./Component/SignUp";
import './App.css';

function App() {
  return (
    <div className="">
      <SignUp/>
    </div>
  );
}

export default App;
